from django.shortcuts import render
from django.shortcuts import render
import speech_recognition as sr
from django.templatetags.i18n import language


def index(request):
    return render(request, 'index/index.html')
